## Execute Mobile Applications by Smart Phone Voice Assistants
