---
description: 개발 방법론
---

# Develop Method

## 1. 형상

## 2. 자동화 

## 3. 테스트

