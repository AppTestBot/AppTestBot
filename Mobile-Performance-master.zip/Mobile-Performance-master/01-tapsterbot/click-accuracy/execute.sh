python3 ClickAutomation.py -i /home/kimsoohyun/00-Research/02-Graph/02-image_detection/04-clickable/dataset/applist.csv -e 5 -p http://localhost:8888

