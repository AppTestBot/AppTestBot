adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION"
#adb -s 230943b313057ece shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION
