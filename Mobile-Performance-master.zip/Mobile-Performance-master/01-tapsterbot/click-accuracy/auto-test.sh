#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv
#! /bin/bash
adb shell getevent -lt /dev/input/event0 | grep "ABS_MT_POSITION" > dataset/03-phoneset/200710_17
python3 ClickAccuacny.py -p ./dataset/robot-test.csv -i http://localhost:8888 > dataset/04-robotset/200710_17.csv

